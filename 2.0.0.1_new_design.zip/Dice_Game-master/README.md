# Dice_Game
Funny game developed with JS during a course online in Umedy. The goal is to roll the dices and try to get the higher amount of points for each round, but ATTENTION! If one of the dices will display a: 1, your turn will end. 
The winner will be the first player who reaches 100 points!
Have fun!
